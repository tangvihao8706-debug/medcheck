package com.medcheck;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.medcheck.model.Medicine;
import com.medcheck.repository.MedicineRepository;

@SpringBootApplication
public class MedcheckApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedcheckApplication.class, args);
    }

    @Bean
    CommandLineRunner initData(MedicineRepository repo) {
        return args -> {

            Medicine m1 = new Medicine();
            m1.setName("Paracetamol");
            m1.setCode("MED001");
            m1.setManufacturer("Sanofi");
            m1.setAgeLimit(6);
            m1.setRiskLevel("Dùng quá liều có thể gây tổn thương gan");
            m1.setRecalled(false);

            Medicine m2 = new Medicine();
            m2.setName("Aspirin");
            m2.setCode("MED002");
            m2.setManufacturer("Bayer");
            m2.setAgeLimit(12);
            m2.setRiskLevel("Không dùng cho trẻ em bị sốt");
            m2.setRecalled(false);

            Medicine m3 = new Medicine();
            m3.setName("Amoxicillin");
            m3.setCode("MED003");
            m3.setManufacturer("GlaxoSmithKline");
            m3.setAgeLimit(6);
            m3.setRiskLevel("Có thể gây dị ứng với người mẫn cảm penicillin");
            m3.setRecalled(false);

            Medicine m4 = new Medicine();
            m4.setName("Ibuprofen");
            m4.setCode("MED004");
            m4.setManufacturer("Pfizer");
            m4.setAgeLimit(12);
            m4.setRiskLevel("Có thể gây kích ứng dạ dày");
            m4.setRecalled(false);

            Medicine m5 = new Medicine();
            m5.setName("Panadol");
            m5.setCode("MED005");
            m5.setManufacturer("GSK");
            m5.setAgeLimit(6);
            m5.setRiskLevel("Không dùng quá liều");
            m5.setRecalled(false);

            Medicine m6 = new Medicine();
            m6.setName("Vitamin C");
            m6.setCode("MED006");
            m6.setManufacturer("DHG Pharma");
            m6.setAgeLimit(3);
            m6.setRiskLevel("Ít tác dụng phụ");
            m6.setRecalled(false);

            Medicine m7 = new Medicine();
            m7.setName("Clorpheniramin");
            m7.setCode("MED007");
            m7.setManufacturer("Imexpharm");
            m7.setAgeLimit(12);
            m7.setRiskLevel("Có thể gây buồn ngủ");
            m7.setRecalled(false);

            Medicine m8 = new Medicine();
            m8.setName("Decolgen");
            m8.setCode("MED008");
            m8.setManufacturer("United Pharma");
            m8.setAgeLimit(12);
            m8.setRiskLevel("Không dùng cho người cao huyết áp");
            m8.setRecalled(false);

            Medicine m9 = new Medicine();
            m9.setName("Hapacol");
            m9.setCode("MED009");
            m9.setManufacturer("DHG Pharma");
            m9.setAgeLimit(6);
            m9.setRiskLevel("Không dùng quá liều");
            m9.setRecalled(false);

            Medicine m10 = new Medicine();
            m10.setName("Tiffy");
            m10.setCode("MED010");
            m10.setManufacturer("Thai Nakorn Patana");
            m10.setAgeLimit(12);
            m10.setRiskLevel("Có thể gây buồn ngủ");
            m10.setRecalled(false);

            repo.save(m1);
            repo.save(m2);
            repo.save(m3);
            repo.save(m4);
            repo.save(m5);
            repo.save(m6);
            repo.save(m7);
            repo.save(m8);
            repo.save(m9);
            repo.save(m10);
        };
    }
}